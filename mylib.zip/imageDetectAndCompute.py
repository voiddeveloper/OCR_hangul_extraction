import cv2 as cv
import numpy as np

imgStandard = cv.imread('img/test_1.jpg')
imgCompute = cv.imread('img/test_4.jpg')
res = None
